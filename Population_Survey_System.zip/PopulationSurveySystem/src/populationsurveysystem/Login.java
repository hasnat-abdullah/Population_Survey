package populationsurveysystem;

public class Login {
    private String AdminUser="admin";
    private static String AdminPass="admin";
    private String EmployeeUser="employee";
    private static String EmployeePass="employee";
    public Login(){}
    
    public boolean AdminLoginCheck(String user, String pass)
    {
        return AdminUser.equals(user) && AdminPass.equals(pass);          
    }
    public boolean EmployeeLoginCheck(String user, String pass)
    {
        return EmployeeUser.equals(user) && EmployeePass.equals(pass);          
    }
    
    public void setAdminPass(String pass) {
        AdminPass = pass;
    }
    public void setEmployeePass(String pass) {
        EmployeePass = pass;
    }
    
}
