package populationsurveysystem;

import java.util.ArrayList;

public class People {
    private String name;
    private String fatherName;
    private String motheName;
    private String spouse;
    private String gender;
    private String dateOfBirth;
    private String NID;
    private String profession;
    private String religion;
    private String maritalStatus;
    private String mobileNumber;
    private String email;
    //------Permanent Address-------    
    private String houseNo;
    private String village;
    private String postOffice;
    private String upazila;
    private String district;
    private String division;
    //------Present Address---------
    private String phouseNo;
    private String pvillage;
    private String ppostOffice;
    private String pupazila;
    private String pdistrict;
    private String pdivision;   
    //------Other details---------
    private int yearlyIncome;
    private int yearlyCost;
    private boolean smoke;
    private boolean socialMedia;
    private boolean Handicapped;
    private boolean mobilePhone;
    private String highestPassCourse;
    
    public static int foundObjectIndex;
    
    
    public People(){}
    
    public People(String name, String fatherName, String motheName, String spouse, String gender, String dateOfBirth, String ID, String profession, String religion, String maritalStatus, String mobileNumber, String email, String houseNo, String village, String postOffice, String upazila, String district, String division, String phouseNo, String pvillage, String ppostOffice, String pupazila, String pdistrict, String pdivision,int yearlyIncome, int yearlyCost, boolean smoke, boolean socialMedia, boolean mobilePhone, boolean Handicapped, String highestPassCourse){
    this.name=name;
    this.fatherName=fatherName;
    this.motheName=motheName;
    this.spouse=spouse;
    this.dateOfBirth=dateOfBirth;
    NID=ID;
    this.profession=profession;
    this.religion=religion;
    this.maritalStatus=maritalStatus;
    this.mobileNumber=mobileNumber;
    this.email=email;
    this.houseNo=houseNo;
    this.village=village;
    this.postOffice=postOffice;
    this.upazila=upazila;
    this.district=district;
    this.division=division;
    this.phouseNo=phouseNo;
    this.pvillage=pvillage;
    this.ppostOffice=ppostOffice;
    this.pupazila=pupazila;
    this.pdistrict=pdistrict;
    this.pdivision=pdivision;
    this.yearlyIncome=yearlyIncome;
    this.yearlyCost=yearlyCost;
    this.smoke=smoke;
    this.socialMedia=socialMedia;
    this.Handicapped=Handicapped;
    this.mobilePhone=mobilePhone;
    this.highestPassCourse=highestPassCourse;    
    }
    
    public void setAllValue(String name, String fatherName, String motheName, String spouse, String gender, String dateOfBirth, String ID, String profession, String religion, String maritalStatus, String mobileNumber, String email, String houseNo, String village, String postOffice, String upazila, String district, String division, String phouseNo, String pvillage, String ppostOffice, String pupazila, String pdistrict, String pdivision,int yearlyIncome, int yearlyCost, boolean smoke, boolean socialMedia, boolean mobilePhone, boolean Handicapped, String highestPassCourse){
    this.name=name;
    this.fatherName=fatherName;
    this.motheName=motheName;
    this.spouse=spouse;
    this.dateOfBirth=dateOfBirth;
    NID=ID;
    this.profession=profession;
    this.religion=religion;
    this.maritalStatus=maritalStatus;
    this.mobileNumber=mobileNumber;
    this.email=email;
    this.houseNo=houseNo;
    this.village=village;
    this.postOffice=postOffice;
    this.upazila=upazila;
    this.district=district;
    this.division=division;
    this.phouseNo=phouseNo;
    this.pvillage=pvillage;
    this.ppostOffice=ppostOffice;
    this.pupazila=pupazila;
    this.pdistrict=pdistrict;
    this.pdivision=pdivision;
    this.yearlyIncome=yearlyIncome;
    this.yearlyCost=yearlyCost;
    this.smoke=smoke;
    this.socialMedia=socialMedia;
    this.Handicapped=Handicapped;
    this.mobilePhone=mobilePhone;
    this.highestPassCourse=highestPassCourse;    
    }
    
    public static boolean searchID(String id){
        if(id.equals(""))   return false;
        for(int i=0; i<Add_People.MangoPeople.size(); i++){
            if( Add_People.MangoPeople.get(i).getID().equals(id));{
            foundObjectIndex= Add_People.MangoPeople.indexOf(Add_People.MangoPeople.get(i));
            return true;
            }
        }
        return false;
    }
    
    /*public static Object getObject(int index){
        return Add_People.MangoPeople.get(index);
    }*/
    
    //==============Setter & Getter Method==============
    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setFatherName(String Fname) {
        fatherName = Fname;
    }

    public String getFatherName() {
        return fatherName;
    }

    public void setMotherName(String Mname) {
        motheName = Mname;
    }

    public String getMotherName() {
        return motheName;
    }

    public void setSpouse(String spouse) {
        this.spouse = spouse;
    }

    public String getSpouse() {
        return spouse;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getGender() {
        return gender;
    }

    public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public String getDateOfBirth() {
        return dateOfBirth;
    }

    public void setID(String ID) {
        NID = ID;
    }

    public String getID() {
        return NID;
    }

    public void setProfession(String profession) {
        this.profession = profession;
    }

    public String getProfession() {
        return profession;
    }

    public void setReligion(String religion) {
        this.religion = religion;
    }

    public String GetReligion() {
        return religion;
    }

    public void setMaritalStatus(String maritalStatus) {
        this.maritalStatus = maritalStatus;
    }

    public String getMaritalStatus() {
        return maritalStatus;
    }

    public void setMobNum(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    public String getMobNum() {
        return mobileNumber;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getEmail() {
        return email;
    }
    
    //==============Setter & Getter Method for Permanent Address===========
    public void setHouseNo(String HouseNo) {
        this.houseNo = HouseNo;
    }

    public String getHouseNo() {
        return houseNo;
    }

    public void setVillage(String village) {
        this.village = village;
    }

    public String getVillage() {
        return village;
    }

    public void setPost(String postOffice) {
        this.postOffice = postOffice;
    }

    public String getPost() {
        return postOffice;
    }

    public void setUpazila(String upazila) {
        this.upazila = upazila;
    }

    public String getUpazila() {
        return upazila;
    }

    public void setDistrict(String district) {
        this.district = district;
    }

    public String getDistrict() {
        return district;
    }

    public void setDivision(String division) {
        this.division = division;
    }

    public String getDivision() {
        return division;
    }
    
    //==============Setter & Getter Method for Present Address===========
    public void setpHouseNo(String HouseNo) {
        phouseNo = HouseNo;
    }

    public String getpHouseNo() {
        return phouseNo;
    }

    public void setpVillage(String village) {
        pvillage = village;
    }

    public String getpVillage() {
        return pvillage;
    }

    public void setpPost(String postOffice) {
        ppostOffice = postOffice;
    }

    public String getpPost() {
        return ppostOffice;
    }

    public void setpUpazila(String upazila) {
        pupazila = upazila;
    }

    public String getpUpazila() {
        return pupazila;
    }

    public void setpDistrict(String district) {
        pdistrict = district;
    }

    public String getpDistrict() {
        return pdistrict;
    }

    public void setpDivision(String division) {
        pdivision = division;
    }

    public String getpDivision() {
        return pdivision;
    }    
    
    //==============Setter & Getter Method for other variable===========
    public void setHighestPassCourse(String highestPassCourse) {
        this.highestPassCourse = highestPassCourse;
    }

    public String getHighestPassCourse() {
        return highestPassCourse;
    }
    
    public void setYearlyIncome(int yearlyIncome) {
        this.yearlyIncome = yearlyIncome;
    }

    public int getYearlyIncome() {
        return yearlyIncome;
    }
    public void setYearlyCost(int yearlyCost) {
        this.yearlyCost = yearlyCost;
    }

    public int getYearlyCost() {
        return yearlyCost;
    }
    
    public void setSmoke(boolean smoke) {
        this.smoke = smoke;
    }

    public boolean getSmoke() {
        return smoke;
    }
    
    public void setSocialMedia(boolean socialMedia) {
        this.socialMedia = socialMedia;
    }

    public boolean getSocialMedia() {
        return socialMedia;
    }
    
    public void setHandicapped(boolean Handicapped) {
        this.Handicapped = Handicapped;
    }

    public boolean getHandicapped() {
        return Handicapped;
    }
    public void setMobilePhone(boolean mobilePhone) {
        this.mobilePhone = mobilePhone;
    }

    public boolean getMobilePhone() {
        return mobilePhone;
    }
}