package populationsurveysystem;

import javax.swing.JFrame;

/**
 *
 * @author Hasnat Abdullah
 */
public class Login_form extends javax.swing.JFrame {

    
    public Login_form() {
        initComponents();
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        user = new javax.swing.JTextField();
        pass = new javax.swing.JPasswordField();
        ErrorShow = new javax.swing.JLabel();
        Login = new javax.swing.JButton();
        adMode = new javax.swing.JRadioButton();
        emMode = new javax.swing.JRadioButton();
        background = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMaximumSize(new java.awt.Dimension(992, 690));
        setMinimumSize(new java.awt.Dimension(992, 690));
        setPreferredSize(new java.awt.Dimension(992, 690));
        getContentPane().setLayout(null);

        user.setBackground(new java.awt.Color(49, 100, 153));
        user.setFont(new java.awt.Font("NeoSans", 1, 24)); // NOI18N
        user.setForeground(new java.awt.Color(255, 255, 255));
        user.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        user.setToolTipText("Enter your username here");
        user.setCaretColor(new java.awt.Color(255, 255, 255));
        user.setSelectionColor(new java.awt.Color(102, 0, 255));
        getContentPane().add(user);
        user.setBounds(360, 270, 270, 50);

        pass.setBackground(new java.awt.Color(49, 100, 153));
        pass.setFont(new java.awt.Font("Arial Black", 0, 24)); // NOI18N
        pass.setForeground(new java.awt.Color(255, 255, 255));
        pass.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        pass.setToolTipText("Enter your password here");
        pass.setSelectionColor(new java.awt.Color(102, 0, 255));
        pass.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                passActionPerformed(evt);
            }
        });
        getContentPane().add(pass);
        pass.setBounds(360, 360, 270, 50);

        ErrorShow.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        ErrorShow.setForeground(new java.awt.Color(255, 0, 0));
        ErrorShow.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        getContentPane().add(ErrorShow);
        ErrorShow.setBounds(330, 160, 330, 30);

        Login.setBackground(new java.awt.Color(39, 89, 143));
        Login.setForeground(new java.awt.Color(39, 89, 143));
        Login.setIcon(new javax.swing.ImageIcon(getClass().getResource("/populationsurveysystem/loginButton.png"))); // NOI18N
        Login.setToolTipText("");
        Login.setBorder(null);
        Login.setBorderPainted(false);
        Login.setContentAreaFilled(false);
        Login.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Login.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LoginActionPerformed(evt);
            }
        });
        getContentPane().add(Login);
        Login.setBounds(390, 450, 200, 60);

        adMode.setBackground(new java.awt.Color(0, 102, 255));
        buttonGroup1.add(adMode);
        adMode.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        adMode.setForeground(new java.awt.Color(255, 255, 255));
        adMode.setText("Admin");
        adMode.setBorder(null);
        adMode.setContentAreaFilled(false);
        adMode.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                adModeActionPerformed(evt);
            }
        });
        getContentPane().add(adMode);
        adMode.setBounds(510, 420, 90, 23);

        emMode.setBackground(new java.awt.Color(0, 102, 204));
        buttonGroup1.add(emMode);
        emMode.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        emMode.setForeground(new java.awt.Color(255, 255, 255));
        emMode.setSelected(true);
        emMode.setText("Employee");
        emMode.setBorder(null);
        emMode.setContentAreaFilled(false);
        emMode.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                emModeActionPerformed(evt);
            }
        });
        getContentPane().add(emMode);
        emMode.setBounds(400, 420, 90, 20);

        background.setIcon(new javax.swing.ImageIcon(getClass().getResource("/populationsurveysystem/login.png"))); // NOI18N
        getContentPane().add(background);
        background.setBounds(0, 0, 990, 650);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void passActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_passActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_passActionPerformed

    private void adModeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_adModeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_adModeActionPerformed

    private void emModeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_emModeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_emModeActionPerformed

    private void LoginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LoginActionPerformed
        Login login= new Login();
        if(emMode.isSelected()){
            if(login.EmployeeLoginCheck(user.getText(),pass.getText())){
                this.dispose();
                Employee_Panel w= new Employee_Panel();
                w.setVisible(true);
                w.setSize(1366,768);
                w.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);           
            }
            else
                ErrorShow.setText("Wrong Employe Username or Password.");
        }
        else{
            if(login.AdminLoginCheck(user.getText(), pass.getText())){
                this.dispose();
                Admin_Panel w= new Admin_Panel();
                w.setVisible(true);
                w.setSize(1366,768);
                w.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
            }
            else
                ErrorShow.setText("Wrong Admin Username or Password.");
        }
    }//GEN-LAST:event_LoginActionPerformed

    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Login_form.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Login_form.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Login_form.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Login_form.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Login_form().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel ErrorShow;
    private javax.swing.JButton Login;
    private javax.swing.JRadioButton adMode;
    private javax.swing.JLabel background;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JRadioButton emMode;
    private javax.swing.JPasswordField pass;
    private javax.swing.JTextField user;
    // End of variables declaration//GEN-END:variables
}
